package com.example.fondodepantalla.FragmentosAdministrador;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.Toast;

import androidx.fragment.app.Fragment;

import com.anton46.stepsview.StepsView;
import com.example.fondodepantalla.R;
import com.google.firebase.firestore.FirebaseFirestore;

public class RegistrarAdmin extends Fragment {

    private StepsView stepsView;
    private FirebaseFirestore db;
    private String taskId;
    private Button btnNextStep;
    private int currentStep = 0;

    private final String[] labels = {
            "Inicio",
            "st1",
            "st2",
            "st3",
            "Completada"
    };

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_registro_admin, container, false);

        stepsView = view.findViewById(R.id.stepsView);
        btnNextStep = view.findViewById(R.id.btnNextStep);
        db = FirebaseFirestore.getInstance();

        if (getArguments() != null) {
            taskId = getArguments().getString("taskId");
        }

        initStepsView();

        if (taskId != null) {
            loadTaskProgress();
        } else {
            Toast.makeText(getContext(), "ID de tarea nulo", Toast.LENGTH_SHORT).show();
        }

        setupButton();

        return view;
    }

    private void initStepsView() {
        stepsView.setLabels(labels)
                .setBarColorIndicator(getResources().getColor(R.color.pastel_gray))
                .setProgressColorIndicator(getResources().getColor(R.color.pastel_purple))
                .setLabelColorIndicator(getResources().getColor(R.color.black))
                .setCompletedPosition(currentStep)
                .drawView();
    }

    private void loadTaskProgress() {
        db.collection("tareas").document(taskId)
                .get()
                .addOnSuccessListener(doc -> {
                    if (doc.exists()) {
                        Long progreso = doc.getLong("progress");
                        if (progreso != null) {
                            currentStep = progreso.intValue();
                            refreshStepsView();
                        }
                    }
                });
    }

    private void updateProgress(int progress) {
        if (taskId == null) return;

        db.collection("tareas").document(taskId)
                .update("progress", progress)
                .addOnSuccessListener(aVoid -> {
                    currentStep = progress;
                    refreshStepsView();
                    Toast.makeText(getContext(), "Avanzaste a: " + labels[progress], Toast.LENGTH_SHORT).show();
                })
                .addOnFailureListener(e ->
                        Toast.makeText(getContext(), "Error al actualizar progreso", Toast.LENGTH_SHORT).show());
    }

    private void refreshStepsView() {
        stepsView.setCompletedPosition(currentStep).drawView();
    }

    private void setupButton() {
        btnNextStep.setOnClickListener(v -> {
            if (currentStep < labels.length - 1) {
                updateProgress(currentStep + 1);
            } else {
                Toast.makeText(getContext(), "Ya estás en el último paso", Toast.LENGTH_SHORT).show();
            }
        });
    }
}
